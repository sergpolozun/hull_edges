# 1 попытка
from typing import List, Any


class Stack:
    def __init__(self) -> None:
        self.__items: List = []

    def push(self, item: Any) -> None:
        """Добавить элемент в стек."""
        self.__items.append(item)

    def pop(self) -> Any:
        """Взять элемент из стека."""
        return self.__items.pop()


def decoding_instructions(instruction: str) -> str:
    """Расшифровывает инструкцию, путем раскрывания вложенных
      последовательностей команд"""
    stack: Stack = Stack()
    current_num: int = 0
    current_seq: List[str] = []

    for char in instruction:
        if '0' <= char <= '9':
            current_num = current_num * 10 + int(char)
        elif char == "[":
            stack.push((current_seq, current_num))
            current_seq = []
            current_num = 0
        elif char == "]":
            last_seq, last_num = stack.pop()
            current_seq = last_seq + current_seq * last_num
        else:
            current_seq.append(char)

    return ''.join(current_seq)


if __name__ == '__main__':
    instruction: str = input()
    print(decoding_instructions(instruction))
